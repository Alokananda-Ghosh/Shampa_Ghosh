package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.beans.TraineeBean;

@Repository
@Transactional
public class TraineeDao implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public List<TraineeBean> getAllTrainee() {
		// TODO Auto-generated method stub
		TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT t FROM TraineeBean t", TraineeBean.class);
		return query.getResultList();
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		TraineeBean trainee = entityManager.find(TraineeBean.class, traineeId);
        
        //Call remove method to remove the entity
        if(trainee != null){
            entityManager.remove(trainee);
            return true;
        }
		return false;
	}

	@Override
	public TraineeBean searchTrainee(int traineeId) {
		// TODO Auto-generated method stub
TraineeBean trainee = entityManager.find(TraineeBean.class, traineeId);
        
        //Call remove method to remove the entity
        return trainee;
		
	}

	@Override
	public boolean updateTrainee(TraineeBean trainee) {
		// TODO Auto-generated method stub
		TraineeBean temp = entityManager.find(TraineeBean.class, trainee.getTraineeId());
		temp.setTraineeDomain(trainee.getTraineeDomain());
		temp.setTraineeId(trainee.getTraineeId());
		temp.setTraineeLocation(trainee.getTraineeLocation());
		temp.setTraineeName(trainee.getTraineeName());
		//entityManager.commit();
		entityManager.getTransaction().commit();
		//entityManager.merge(trainee);
		//modify trainee if you wish.
		//entityManager.commit();
		return false;
	}

}
